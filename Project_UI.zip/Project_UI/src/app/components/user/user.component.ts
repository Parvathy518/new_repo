import { Component, OnInit } from '@angular/core';
import { UserService } from '../../service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  serverError:Boolean = false;
  addUserForm: FormGroup = new FormGroup({
    firstName: new FormControl('', [
      Validators.required,
      Validators.minLength(3)
    ]),
    lastName: new FormControl('', [
      Validators.required,
    ]),
    introduction: new FormControl('', [
    ]),
    email: new FormControl('', [
      Validators.required,
      Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")
    ]),
    phone: new FormControl('', [
      Validators.pattern('[- +()0-9]+')
    ]),
    experience: new FormControl('', [
    ]),
    achievements: new FormControl('', [
    ])
  });
  users: any = [];
  constructor(private userService : UserService) { }

  ngOnInit(): void {

    this.userService.fetchAllUsers()
    .then((response: any) => {
      this.users = response;
    })
    .catch(() => {

    });
  }
  onSubmit(): void {
    this.userService.addUserData(this.addUserForm.value)
    .then(() => {
      this.addUserForm.reset();
      this.userService.fetchAllUsers()
    .then((response: any) => {
      this.users = response;
    })
    .catch(() => { });
    })
    .catch((e) => {
      if (e.error.message == "User with same email id already exists") {
        this.serverError = true
      }
    });
  }
}
