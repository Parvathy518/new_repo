import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Custom component
import {
  UserDetailsComponent,
  UserComponent
} from './components';

const routes: Routes = [
    { path: 'user-details/:emailid', component: UserDetailsComponent },
    { path: 'user-list', component: UserComponent },
    { path: '**', redirectTo: '/user-list' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, {scrollPositionRestoration: 'enabled'})],
    exports: [RouterModule]
})
export class AppRoutingModule { }