import { UserDetailsComponent } from "./user-details/user-details.component";
import { UserComponent } from "./user/user.component";

export {
  UserComponent,
  UserDetailsComponent
};

