/*
 * File Name: index.js
 * Description: Server application entry point
 * Creation Date: 11/04/2021
 */

const startServer = require('./src/server')

// Start the server
const start = async () => {
  try {
    await startServer()
  }
  catch (err) {
    process.exit(1)
  }
}

start()
