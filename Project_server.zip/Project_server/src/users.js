/*
 * File Name: users.js
 * Description: A router module for users add and view
 * Creation Date: 11/4/2021
 */

var express = require('express')
const cors = require('cors')
var bodyParser = require("body-parser"); //Parse incoming request bodies

require('./user-service.js')

var router = express.Router()

router.use(cors({ origin: '*' }))
router.use(bodyParser.urlencoded({extended: false}));
router.use(bodyParser.json());//parse application/json





router.post('/', function(req ,res) {
    res.setHeader('Access-Control-Allow-Origin', '*')
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
    var userObj = new UserService()
    var formValues = {}
    formValues.firstName = req.body.firstName
    formValues.lastName = req.body.lastName
    formValues.introduction = req.body.introduction
    formValues.email = req.body.email
    formValues.phone = req.body.phone
    formValues.experience = req.body.experience
    formValues.achievements = req.body.achievements
    userObj.addNewUser(formValues, function (responseType, responseMsg){
      var responseData = {
        "Response": {
          "status": responseType,
          "message": responseMsg
        }
      }

      res.status(200).end(JSON.stringify(responseData, null, 3))
    });
});

router.get('/', function (req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  var userObj = new UserService()
  userObj.fetchAllUsers(function (responseType, responseMsg) {
    var responseData = {
      "Response": {
        "status": responseType,
        "message": responseMsg
      }
    }

    res.status(200).end(JSON.stringify(responseData, null, 3))
  })
})

router.get('/:email', function (req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  var userObj = new UserService()
  var email = req.params.email
  userObj.fetchUser(email, function (responseType, responseMsg) {
    var responseData = {
      "Response": {
        "status": responseType,
        "message": responseMsg
      }
    }

    res.status(200).end(JSON.stringify(responseData, null, 3))
  })
})


module.exports = router
