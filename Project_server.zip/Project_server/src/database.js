/*
 * File Name: database.js
 * Description: database connection details
 * Creation Date: 11/4/2021
 */

var Sequelize = require('sequelize')

const sequelize = new Sequelize('newdb', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  multipleStatements: 'true',
  define: {
    timestamps: false
  }
});

database = function () {

  this.userModel = sequelize.define(
    'users',
    {
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      firstName: {
        type: Sequelize.STRING
      },
      lastName: {
        type: Sequelize.STRING
      },
      introduction: {
        type: Sequelize.STRING
      },
      email: {
        type: Sequelize.STRING
      },
      phone: {
        type: Sequelize.STRING
      },
      experience: {
        type: Sequelize.INTEGER
      },
      achievements: {
        type: Sequelize.STRING
      }
    },
    {
      tableName: 'users'
    },
    {
      timestamps: false
    },
    {
      underscored: true
    }
  )

};

module.exports = database
