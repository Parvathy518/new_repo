/*
 * File Name: server.js
 * Description: Server file that handles routing.
 * Creation Date: 11/4/2021
 */

const cors = require("cors");
const express = require("express");

const routeUsers = require("./users");

const app = express();


const startServer = async () => {

  app.listen(8080, function() {
    console.log("Listening on port 8080")
  });
  app.use(cors({ origin: "*" }));


  app.use("/users", routeUsers);

};

module.exports = startServer;
