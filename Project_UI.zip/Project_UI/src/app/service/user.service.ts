import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  fetchAllUsers(){
    return new Promise((resolve, reject) => {
      this.http.get(`/api/users`)
        .subscribe(
          (data: any) => {
            resolve(data.Response.message);
          },
          err => {
            reject(err);
          }
        );
    });
  }
  addUserData(formValues:any) {
    return new Promise((resolve, reject) => {
      this.http.post(`/api/users`, formValues).subscribe(
        (data: any) => {
          resolve(data);
        },
        err => {
          reject(err);
        }
      );
    });
  }
  getUserDetails(emailid:any) {
    return new Promise((resolve, reject) => {
      this.http.get(`/api/users/${emailid}`).subscribe(
        (data: any) => {
          resolve(data.Response.message);
        },
        err => {
          reject(err);
        }
      );
    });
  }
}
