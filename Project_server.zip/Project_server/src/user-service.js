/*
 * File Name: user-service.js
 * Description: Create a service module for users
 * Creation Date: 11/4/2021
 */
var Sequelize = require('sequelize')

require('./database')

var db = new database()

UserService = function () {

  this.addNewUser = function(formValues, sendResponse) {
    db.userModel.findOne({
      attributes: ['user_id', 'email'],
      where: {email: formValues.email}
    }).then(function(user) {
      if (user) {
        sendResponse("error", "User with same email id already exists")
      }
      else {
        db.userModel.create(formValues).then(function() {
          sendResponse("success", "created")
        }).catch(err => sendResponse("error", err))
      }
    })

  }

  this.fetchAllUsers = function(sendResponse) {
    db.userModel.findAll({
      attributes: ["firstName", "lastName", "email"]
    }).then(function(users) {
      sendResponse("success", users)
    }).catch(err => sendResponse("error", err))
  }

  this.fetchUser = function(emailId, sendResponse) {
    db.userModel.findOne({
      where: {email: emailId}
    }).then(function(user) {
      sendResponse("success", user)
    }).catch(err => sendResponse("error", err))
  }

}
module.exports = UserService
